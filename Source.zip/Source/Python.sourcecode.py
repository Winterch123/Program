from tkinter import *
from tkinter import ttk
from tkinter.messagebox import*
from winreg import*

tk= Tk()
tk.title('창을 닫아보거라')

tk.geometry("750x250")

def close_win():
   win.destroy()

def disable_event():
   pass

def 크크크():
    showerror("크크크", "작업관리자는 막혔지~")

def 크크크2():
    showerror("크크크", "cmd도 막혔지~")

def 크크크3():
    showerror("크크킄", "이건 가짜지롱~")

label = Label(tk,text='창을 닫아보거라',font=10)
label.pack()

btn1 = Button(tk,text='닫기',width=5,height=5,font=3,command= 크크크3)
btn1.pack(side=RIGHT,padx=10,pady=10)

btn2 = Button(tk,text='작업관리자',width=10,height=3,font=2,command= 크크크)
btn2.pack(side=LEFT,padx=10,pady=10)

btn3 = Button(tk,text='cmd',width=5,height=3,font=2,command= 크크크2)
btn3.pack(side=LEFT,padx=10,pady=10)

tk.protocol("WM_DELETE_WINDOW", disable_event)
tk.attributes('-toolwindow', True)

tk.mainloop()